package Empresa_MarketAll;

public class Pago_Debito extends Pago{
	
}
