package Empresa_MarketAll;

public class Pago {
	protected double monto;
	
	public void setMonto(double valor) {
		monto = valor;
	}
	
	public double getMonto() {
		return monto;
	}
	
	public double calcularMonto() {
		return monto;
	}
}
